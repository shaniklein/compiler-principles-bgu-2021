The test is comparing the output of our code to yours.

In order to run the test follow this steps:
1. extract the test folder to the directory in your machine that contains "reader.ml" "pc.ml"
2. open the terminal in test folder and run:
   a. chmod +x run_tests.sh
   b. ./run_tests.sh

If the output is clean we have the same output for each test.
Note: OCaml may print some information about some libraries it loads.
      You  can safely ignore it.